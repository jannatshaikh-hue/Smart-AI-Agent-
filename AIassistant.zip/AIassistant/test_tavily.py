# test_tavily.py
import requests

api_key = "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"
url = "https://api.tavily.com/search"

print("Testing Tavily API...")
print(f"API Key: {api_key[:15]}...")

data = {
    "api_key": api_key,
    "query": "what is artificial intelligence",
    "search_depth": "basic",
    "max_results": 3
}

try:
    response = requests.post(url, json=data)
    print(f"Status Code: {response.status_code}")
    
    if response.status_code == 200:
        result = response.json()
        print("✅ SUCCESS!")
        if 'results' in result:
            print(f"Found {len(result['results'])} results")
            for i, r in enumerate(result['results'][:2], 1):
                print(f"\nResult {i}: {r.get('title', 'No title')}")
        else:
            print("Response:", result)
    else:
        print(f"❌ Error: {response.text}")
except Exception as e:
    print(f"❌ Exception: {e}")

print("\nTest complete!")