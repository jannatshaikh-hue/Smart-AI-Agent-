# test_config.py
try:
    from config import config
    print("✅ SUCCESS: config imported correctly!")
    print(f"📁 Data directory: {config.DATA_DIR}")
    print(f"🤖 Embedding model: {config.EMBEDDING_MODEL}")
    print(f"📊 Top K results: {config.TOP_K_RESULTS}")
    print(f"🎯 Quiz questions: {config.QUESTIONS_PER_QUIZ}")
    
    # Test all major attributes
    required_attrs = [
        'DATA_DIR', 'UPLOAD_DIR', 'VECTOR_STORE_DIR', 'DB_PATH',
        'EMBEDDING_MODEL', 'CHUNK_SIZE', 'USE_LOCAL_LLM',
        'TOP_K_RESULTS', 'QUESTIONS_PER_QUIZ'
    ]
    
    for attr in required_attrs:
        if hasattr(config, attr):
            print(f"✅ Found: {attr}")
        else:
            print(f"❌ Missing: {attr}")
            
except ImportError as e:
    print(f"❌ ERROR: {e}")
    
    # Alternative import
    try:
        import config as cfg
        print("\nTrying alternative import 'import config as cfg'...")
        print(f"✅ cfg.DATA_DIR = {cfg.DATA_DIR}")
        print("⚠️ But you need 'from config import config' for app.py")
    except:
        print("❌ Both imports failed")