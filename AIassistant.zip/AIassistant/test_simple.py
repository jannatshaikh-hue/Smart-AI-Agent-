﻿# test_simple.py
import os
import sys

print('='*50)
print('TESTING SETUP')
print('='*50)

print(f'Current directory: {os.getcwd()}')

# Test core folder
if os.path.exists('core'):
    print('✅ core folder exists')
    print(f'   Files: {os.listdir("core")}')
else:
    print('❌ core folder missing')

# Test imports
try:
    from core.rag_engine import EnhancedRAGEngine
    print('✅ Can import EnhancedRAGEngine')
except Exception as e:
    print(f'❌ Import failed: {e}')

try:
    from core.document_processor import DocumentProcessor
    print('✅ Can import DocumentProcessor')
except Exception as e:
    print(f'❌ Import failed: {e}')

try:
    from core.quiz_generator import QuizGenerator
    print('✅ Can import QuizGenerator')
except Exception as e:
    print(f'❌ Import failed: {e}')

try:
    from core.knowledge_tracer import KnowledgeTracer
    print('✅ Can import KnowledgeTracer')
except Exception as e:
    print(f'❌ Import failed: {e}')

print('='*50)
