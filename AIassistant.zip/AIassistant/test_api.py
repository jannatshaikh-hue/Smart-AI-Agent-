# test_api.py
import requests

# Your API keys
API_KEY = "AIzaSyDVM5FQncwI8SrIRq_2m9qiU4Hwx4h6So8"
CX = "b117b5550b3454110"

# Test query
query = "what is artificial intelligence"

url = "https://www.googleapis.com/customsearch/v1"
params = {
    'key': API_KEY,
    'cx': CX,
    'q': query,
    'num': 3
}

print("Testing Google Custom Search API...")
print(f"URL: {url}")
print(f"Params: {params}\n")

try:
    response = requests.get(url, params=params)
    print(f"Status Code: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        
        # Check if items exist
        if 'items' in data:
            print(f"\n✅ SUCCESS! Found {len(data['items'])} results")
            for i, item in enumerate(data['items'], 1):
                print(f"\n--- Result {i} ---")
                print(f"Title: {item.get('title', 'N/A')}")
                print(f"Snippet: {item.get('snippet', 'N/A')[:100]}...")
                print(f"Link: {item.get('link', 'N/A')}")
        else:
            print("❌ No 'items' in response")
            print("Response:", data)
    else:
        print(f"❌ Error: {response.status_code}")
        print("Response:", response.text)
        
except Exception as e:
    print(f"❌ Exception: {e}")