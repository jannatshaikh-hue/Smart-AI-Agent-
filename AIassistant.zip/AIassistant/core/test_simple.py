# test_simple.py
import requests

api_key = "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"
url = "https://api.tavily.com/search"

payload = {
    "api_key": api_key,
    "query": "artificial intelligence",
    "search_depth": "basic",
    "max_results": 3
}

print("Testing Tavily API...")
try:
    response = requests.post(url, json=payload)
    print(f"Status Code: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        print("✅ SUCCESS! API is working!")
        if "results" in data:
            print(f"Found {len(data['results'])} results")
            for i, r in enumerate(data['results'][:2], 1):
                print(f"\n{i}. {r.get('title')}")
    else:
        print(f"❌ Error: {response.text}")
except Exception as e:
    print(f"❌ Exception: {e}")