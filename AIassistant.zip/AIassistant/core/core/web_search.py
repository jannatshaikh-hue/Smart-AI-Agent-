# core/web_search.py
import requests

class WebSearchAgent:
    """Web search agent using Tavily API"""
    
    def __init__(self, tavily_api_key=None):
        self.tavily_api_key = tavily_api_key
        self.api_url = "https://api.tavily.com/search"
        print(f"✅ WebSearchAgent initialized with key: {tavily_api_key[:10] if tavily_api_key else 'None'}...")
    
    def search_web(self, query, num_results=5):
        """Search the web using Tavily API (matches what app.py expects)"""
        if not self.tavily_api_key:
            print("No API key provided")
            return []
        
        try:
            # Prepare payload
            payload = {
                "api_key": self.tavily_api_key,
                "query": query,
                "search_depth": "basic",
                "max_results": num_results
            }
            
            # Make request
            print(f"Searching Tavily for: {query}")
            response = requests.post(self.api_url, json=payload, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                results = []
                
                if "results" in data:
                    for item in data["results"]:
                        results.append({
                            'title': item.get('title', 'No title'),
                            'snippet': item.get('content', 'No content'),
                            'link': item.get('url', '#'),
                            'source': 'tavily'
                        })
                    print(f"Found {len(results)} results")
                    return results
                else:
                    print("No results in response")
                    return []
            else:
                print(f"API Error: {response.status_code}")
                return []
                
        except Exception as e:
            print(f"Search error: {e}")
            return []
    
    def answer_question(self, query):
        """Answer a question using web search"""
        print(f"Answering: {query}")
        results = self.search_web(query)
        
        if results:
            answer = f"**Here's what I found about '{query}':**\n\n"
            
            for i, result in enumerate(results[:3], 1):
                answer += f"**{i}. {result['title']}**\n"
                answer += f"{result['snippet'][:200]}...\n"
                answer += f"🔗 [Source]({result['link']})\n\n"
            
            answer += "💡 *Results from Tavily web search*"
            
            return {
                'answer': answer,
                'sources': results[:3],
                'type': 'web_search'
            }
        else:
            return {
                'answer': f"I couldn't find information about '{query}'. Please check your API key in Settings.",
                'sources': [],
                'type': 'fallback'
            }