# core/document_processor.py
import os
import hashlib
from pathlib import Path
import PyPDF2
import pdfplumber

class DocumentProcessor:
    def __init__(self, config):
        self.config = config
        print("✅ Document Processor initialized with PDF support")
    
    def process_file(self, file_path):
        """Process a file and extract text based on file type"""
        file_path = Path(file_path)
        filename = file_path.name
        extension = file_path.suffix.lower()
        
        print(f"Processing {filename}...")
        
        # Extract text based on file type
        if extension == '.pdf':
            text = self._extract_from_pdf(file_path)
        elif extension == '.txt':
            text = self._extract_from_txt(file_path)
        elif extension == '.docx':
            text = self._extract_from_docx(file_path)
        elif extension == '.md':
            text = self._extract_from_md(file_path)
        else:
            text = f"Unsupported file type: {extension}"
        
        # Generate a unique ID
        doc_id = hashlib.md5(f"{filename}_{os.path.getsize(file_path)}".encode()).hexdigest()
        
        print(f"✅ Extracted {len(text)} characters from {filename}")
        
        return {
            "doc_id": doc_id,
            "filename": filename,
            "text": text,
            "text_length": len(text),
            "metadata": {
                "source": filename,
                "type": extension[1:] if extension else 'unknown',
                "size": os.path.getsize(file_path)
            }
        }
    
    def _extract_from_pdf(self, file_path):
        """Extract text from PDF files"""
        text = ""
        
        # Try pdfplumber first (better for complex PDFs)
        try:
            with pdfplumber.open(file_path) as pdf:
                for i, page in enumerate(pdf.pages):
                    page_text = page.extract_text()
                    if page_text:
                        text += f"\n--- Page {i+1} ---\n{page_text}\n"
            print(f"✅ pdfplumber extracted {len(text)} chars")
        except Exception as e:
            print(f"pdfplumber failed: {e}, trying PyPDF2...")
            # Fallback to PyPDF2
            try:
                with open(file_path, 'rb') as file:
                    reader = PyPDF2.PdfReader(file)
                    for i, page in enumerate(reader.pages):
                        page_text = page.extract_text()
                        if page_text:
                            text += f"\n--- Page {i+1} ---\n{page_text}\n"
                print(f"✅ PyPDF2 extracted {len(text)} chars")
            except Exception as e2:
                print(f"PyPDF2 also failed: {e2}")
                text = f"Could not extract text from PDF. The file may be scanned or protected."
        
        return text if text.strip() else "No text could be extracted from this PDF."
    
    def _extract_from_txt(self, file_path):
        """Extract text from text files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except UnicodeDecodeError:
            # Try different encoding
            try:
                with open(file_path, 'r', encoding='latin-1') as f:
                    return f.read()
            except:
                return "Could not read text file."
    
    def _extract_from_docx(self, file_path):
        """Extract text from Word documents"""
        try:
            from docx import Document
            doc = Document(file_path)
            text = "\n".join([paragraph.text for paragraph in doc.paragraphs])
            return text if text else "No text found in Word document."
        except ImportError:
            return "python-docx not installed. Run: pip install python-docx"
        except Exception as e:
            return f"Error reading Word document: {e}"
    
    def _extract_from_md(self, file_path):
        """Extract text from Markdown files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except:
            return "Could not read markdown file."