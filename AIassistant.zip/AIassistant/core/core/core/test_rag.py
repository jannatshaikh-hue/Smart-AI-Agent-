@"
# test_rag.py
import sys
import os

print('='*50)
print('TESTING RAG ENGINE')
print('='*50)

try:
    from core.rag_engine import EnhancedRAGEngine
    print('✅ Import successful')
    
    # Create instance
    engine = EnhancedRAGEngine(None)
    print('✅ Instance created')
    
    # Test add_documents
    test_docs = [{'filename': 'test.txt', 'text': 'test content'}]
    result = engine.add_documents(test_docs)
    print(f'✅ add_documents returned: {result}')
    
    # Verify documents were added
    print(f'✅ Documents count: {len(engine.documents)}')
    
    print('\n✅ All tests passed!')
    
except Exception as e:
    print(f'❌ Error: {e}')
    import traceback
    traceback.print_exc()

print('='*50)
"@ | Out-File -FilePath test_rag.py -Encoding UTF8
