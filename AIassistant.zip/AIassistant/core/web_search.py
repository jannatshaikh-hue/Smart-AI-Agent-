﻿class WebSearchAgent:
    def __init__(self, tavily_api_key=None):
        self.tavily_api_key = tavily_api_key
        print(f"Agent created with key: {tavily_api_key}")
    
    def answer_question(self, query):
        return {
            "answer": f"Test response for: {query}",
            "sources": []
        }
