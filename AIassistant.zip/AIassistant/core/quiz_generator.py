﻿# core/quiz_generator.py
class QuizGenerator:
    def __init__(self, config):
        self.config = config
        print("✅ Quiz Generator initialized")
    
    def generate_quiz(self, documents, num_questions=5, difficulty="medium", focus_topics=None):
        return {
            "id": "quiz1",
            "title": "Sample Quiz",
            "questions": [],
            "created_date": "2024-01-01"
        }
