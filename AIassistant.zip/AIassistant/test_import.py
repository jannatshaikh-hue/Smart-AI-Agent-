﻿print('Testing imports...')
try:
    from core.rag_engine import EnhancedRAGEngine
    print('✅ Import successful!')
except Exception as e:
    print(f'❌ Import failed: {e}')
