﻿# test_imports.py
print('Testing imports...')

try:
    from config import config
    print('✅ config imported')
except ImportError as e:
    print(f'❌ config import failed: {e}')

try:
    from core.document_processor import DocumentProcessor
    print('✅ document_processor imported')
except ImportError as e:
    print(f'❌ document_processor import failed: {e}')

try:
    from core.quiz_generator import QuizGenerator
    print('✅ quiz_generator imported')
except ImportError as e:
    print(f'❌ quiz_generator import failed: {e}')

try:
    from core.knowledge_tracer import KnowledgeTracer
    print('✅ knowledge_tracer imported')
except ImportError as e:
    print(f'❌ knowledge_tracer import failed: {e}')

try:
    from core.rag_engine import EnhancedRAGEngine
    print('✅ rag_engine imported')
except ImportError as e:
    print(f'❌ rag_engine import failed: {e}')

print('\nTest complete!')
