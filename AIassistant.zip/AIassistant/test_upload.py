import streamlit as st

st.set_page_config(page_title="Test Upload", page_icon="🔧")

st.title("File Upload Test")

# Simple file uploader
uploaded_file = st.file_uploader("Choose a file", type=['txt', 'pdf', 'docx'])

if uploaded_file is not None:
    st.success(f"File uploaded: {uploaded_file.name}")
    st.write(f"File size: {len(uploaded_file.getvalue())} bytes")
else:
    st.info("Please upload a file")