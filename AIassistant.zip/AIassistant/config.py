﻿# config.py
class Config:
    DATA_DIR = "./data"
    UPLOAD_DIR = "./data/uploads"
    VECTOR_STORE_DIR = "./data/vector_store"
    DB_PATH = "./data/user_progress.db"
    CHUNK_SIZE = 500
    TOP_K_RESULTS = 3
    USE_LOCAL_LLM = True
    EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

config = Config()
